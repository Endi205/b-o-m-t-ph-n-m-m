# LAB_4: Xác minh khuôn mặt 1:1 với DeepFace trên LFW

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th04_verify.py`
- `bio_metrics.py`
- `ket-qua/TH04_bang-cau-hinh.csv`
- `ket-qua/TH04_det.png`

Phép tự kiểm sẽ xem:

- ít nhất 5 cấu hình, có FTA và số cặp bị bỏ
- đủ ba mô hình
- ít nhất hai bộ phát hiện

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Không đưa thư mục cache-embedding/ lên kho: embedding là dữ liệu dẫn xuất từ ảnh khuôn mặt.
