# LAB_6: Xác minh người nói: EER theo độ dài câu

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th06_speaker.py`
- `bio_metrics.py`
- `ket-qua/TH06_eer-theo-do-dai.csv`
- `ket-qua/TH06_eer-theo-do-dai.png`

Phép tự kiểm sẽ xem:

- đủ 5 độ dài cho hai bộ trích
- có cả MFCC và ECAPA

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Không đưa tệp âm thanh lên kho.
