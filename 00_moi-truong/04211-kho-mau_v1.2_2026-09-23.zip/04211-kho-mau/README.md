# Kho bài làm học phần 04211 Bảo mật sinh trắc

Đây là kho riêng tư (private repository) của một sinh viên. Chỉ sinh viên và giảng viên xem được.

## Thông tin sinh viên

| Mục | Điền vào đây |
|---|---|
| Họ và tên | |
| Mã số sinh viên (MSSV) | |
| Lớp | 2610421101 |
| Tài khoản GitHub | |

Điền ngay trên trình duyệt: bấm biểu tượng cây bút (**Edit this file**) ở góc phải của tệp này, gõ vào các ô trống, rồi bấm **Commit changes**.

## Kho này chứa gì

| Chỗ | Chứa gì |
|---|---|
| `lab01/` tới `lab10/` | Mỗi bài lab một thư mục; `README.md` trong thư mục ghi đúng tệp của bài |
| `AI-SUDUNG.md` | Khai báo việc dùng trợ lý lập trình (AI assistant) |
| `.github/workflows/tu-kiem.yml`, `.kiem/` | Phép tự kiểm, chạy sau mỗi lần ghi nhận; xem kết quả ở thẻ **Actions**. Không sửa |

## Không bao giờ đưa lên kho

Ảnh vân tay, khuôn mặt, mống mắt, tệp âm thanh giọng nói, tập dữ liệu tải về (thư mục `data/`), tệp `.npy`, `.pkl`, `.db` (kể cả `fingerprint_templates.db`), thư mục `cache-embedding/`, `db-tham-chieu/`, kho mẫu và nhật ký của TH10, trọng số mô hình, thư mục `venv/`. Đó là dữ liệu sinh trắc học hoặc dữ liệu dẫn xuất từ nó; lịch sử Git giữ mọi phiên bản, nên xoá ở lần ghi nhận sau không xoá được bản đã đưa lên.
