# Khai báo dùng trợ lý lập trình (AI assistant)

Không dùng.

## Cách khai báo (phần hướng dẫn, không phải lời khai báo)

Nếu có dùng: xoá dòng "Không dùng." ở trên. Với mỗi lần dùng, chép khối bốn dòng dưới đây xuống cuối tệp rồi điền vào. Giữ bốn dấu cách ở đầu mỗi dòng để GitHub hiện đủ bốn dòng riêng.

    Ngày:        2026-10-07
    Công cụ:     tên công cụ và phiên bản nếu biết
    Phần việc:   dùng vào việc gì, ở tệp nào, dòng nào
    Câu đã hỏi:  chép nguyên văn câu hỏi đã đặt cho công cụ

Theo quy định của học phần, sinh viên được dùng công cụ AI để hỏi giải thích và gỡ lỗi, nhưng phải giải thích được mọi dòng mã và mọi con số trong bài khi giảng viên hỏi.
