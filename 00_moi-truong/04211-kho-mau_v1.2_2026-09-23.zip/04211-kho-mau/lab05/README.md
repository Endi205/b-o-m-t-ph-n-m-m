# LAB_5: Định danh khuôn mặt 1:N: CMC, FPIR, FNIR

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th05_identify.py`
- `bio_metrics.py`
- `ket-qua/TH05_cmc.csv`
- `ket-qua/TH05_quy-mo.csv`
- `ket-qua/TH05_cmc-fpir-fnir.png`

Phép tự kiểm sẽ xem:

- bảng CMC
- CMC không giảm theo hạng
- bảng quy mô
- FPIR tăng theo N

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Xoá db-tham-chieu/ sau bước 6 và không đưa nó lên kho.
