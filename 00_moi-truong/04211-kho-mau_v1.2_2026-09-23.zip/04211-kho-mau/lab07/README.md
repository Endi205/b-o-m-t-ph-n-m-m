# LAB_7: IrisCode, khoảng cách Hamming có bù xoay và hợp nhất điểm

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th07_iriscode.py`
- `bio_metrics.py`
- `ket-qua/TH07_bang-iriscode.csv`
- `ket-qua/TH07_phan-bo-hd.png`
- `ket-qua/TH07_minh-hoa-pipeline.png`

Tệp nên có:

- `th07_fusion.py`
- `ket-qua/TH07_bang-hop-nhat.csv`
- `ket-qua/TH07_det-hop-nhat.png`

Phép tự kiểm sẽ xem:

- bảng IrisCode đủ 4 phạm vi dịch
- HD trung bình khác người khi không dịch trong khoảng 0,47 đến 0,53
- EER với dịch 8 cột không quá 5%

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Hình minh hoạ pipeline chỉ dùng ảnh mống mắt tổng hợp.
