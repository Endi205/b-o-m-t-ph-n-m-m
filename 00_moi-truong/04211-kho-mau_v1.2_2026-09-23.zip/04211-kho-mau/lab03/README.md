# LAB_3: Tăng cường ảnh vân tay và trích minutiae

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th02_minutiae.py`
- `ket-qua/TH02_bang-minutiae.csv`
- `ket-qua/TH02_bang-nhieu.csv`

Tệp nên có:

- `ket-qua/TH02_*_minutiae.png`

Phép tự kiểm sẽ xem:

- bảng nhiễu đủ 4 mức

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Chỉ đưa ảnh chồng minutiae của ảnh tổng hợp; không đưa ảnh tăng cường hay ảnh xương của FVC.
