# LAB_2: Tự tính các chỉ số đánh giá hiệu năng: FMR, FNMR, EER, DET

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `bio_metrics.py`
- `test_bio_metrics.py`
- `th01_main.py`
- `ket-qua/TH01_*_bang-ket-qua.csv`
- `ket-qua/TH01_*_det.png`

Tệp nên có:

- `ket-qua/TH01_*_phan-bo-diem.png`
- `ket-qua/TH01_*_roc.png`

Phép tự kiểm sẽ xem:

- tệp kết quả mang MSSV (chạy th01_main.py --ma-sv)
- bảng kết quả đủ cột, đủ ba hệ thống
- EER tự tính lệch pyeer không quá 0,5 điểm phần trăm

Kiểm thử công khai chạy trên máy của GitHub mỗi lần ghi nhận: `python test_bio_metrics.py`. Không sửa các tệp kiểm thử được phát sẵn (`test_bio_metrics.py`).

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Chạy th01_main.py với --ma-sv <MSSV> để tên tệp kết quả mang MSSV; không tải thư mục data/ lên kho.
