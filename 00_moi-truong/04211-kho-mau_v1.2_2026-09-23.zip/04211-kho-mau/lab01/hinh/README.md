Ảnh chụp màn hình của bài này. Không đặt ảnh sinh trắc ở đây.
