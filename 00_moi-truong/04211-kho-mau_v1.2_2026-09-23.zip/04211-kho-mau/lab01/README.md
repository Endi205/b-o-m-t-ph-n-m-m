# LAB_1: Phân tích hệ thống nhận dạng vân tay (AFIS)

Tệp nên có:

- `bao-cao.md`

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Tệp PDF và tệp nén theo hướng dẫn LAB_1, không nộp qua kho.

Ghi chú: Chép báo cáo LAB_1 vào bao-cao.md để tập thao tác; phần này không tính vào bài.
