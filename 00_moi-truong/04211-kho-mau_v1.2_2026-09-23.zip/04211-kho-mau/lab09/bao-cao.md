# Báo cáo thực hành LAB_9: Bảo vệ mẫu sinh trắc: BioHashing, cam kết mờ, so khớp trên dữ liệu mã hoá

Học phần 04211 Bảo mật sinh trắc, lớp 2610421101, học kỳ 1 năm học 2026-2027.

| Mục | Điền vào đây |
|---|---|
| Họ và tên | {họ và tên} |
| Mã số sinh viên | {MSSV} |
| Ngày nộp | {dd/mm/yyyy} |

<!-- Cách dùng mẫu: giữ nguyên thứ tự và tên mười mục có dấu ##. Thay mọi chỗ trong ngoặc nhọn
bằng nội dung của em. Các khối chú thích như khối này không hiện ra khi xem trên GitHub, nên
không cần xoá. Mục nào không áp dụng thì ghi "Không áp dụng" kèm lý do trong một dòng.
Chèn đồ thị bằng dòng ![Hình 1: mô tả](ket-qua/ten-do-thi.png) hoặc ![Hình 2: mô tả](hinh/ten-anh.png) -->

## 1. Tóm tắt kết quả

<!-- 3 đến 5 câu. Nêu con số quan trọng nhất kèm điều kiện đo (cỡ mẫu, ngưỡng). Nói thẳng phần
chưa làm được và lý do. -->

{tóm tắt}

## 2. Mức độ hoàn thành

<!-- Mỗi bước hoặc yêu cầu của đề là một dòng. Trạng thái: Hoàn thành, Một phần, Chưa làm. -->

| Bước hoặc yêu cầu trong đề | Trạng thái | Minh chứng tại mục |
|---|---|---|
| {Bước 1} | {trạng thái} | 4.1 |
| {Bước 2} | {trạng thái} | 4.2 |

## 3. Môi trường thực hiện và khả năng tái lập

<!-- Một người khác chỉ cần bảng này là chạy lại được đúng kết quả. Lấy thông tin bằng lệnh. -->

| Thông tin | Giá trị |
|---|---|
| Hệ điều hành, CPU, RAM | {...} |
| Phiên bản Python | {kết quả của python --version} |
| Thư viện chính và phiên bản | {trích từ pip freeze} |
| Dữ liệu | {tên tập, tập con, số mẫu, nguồn tải} |
| Hạt giống ngẫu nhiên | {giá trị, hoặc "không dùng"} |
| Lệnh chạy chính | {các lệnh theo thứ tự} |
| Thời gian chạy | {đo được} |

## 4. Các bước thực hiện và minh chứng

<!-- Mỗi bước của đề một tiểu mục ###, gồm: việc đã làm, lệnh hoặc đoạn mã chính, minh chứng,
nhận xét. Kết quả chạy chép dạng văn bản trong khối ``` tốt hơn ảnh chụp. -->

### 4.1. {Bước 1}

{việc đã làm, lệnh, minh chứng, nhận xét}

## 5. Kết quả định lượng

<!-- Bảng và hình có số thứ tự và chú thích. Ghi công thức, ngưỡng, cỡ mẫu. Số liệu lấy từ tệp
CSV trong ket-qua/ do chương trình ghi ra, không chép tay. -->

{bảng và hình}

## 6. Phân tích và thảo luận

<!-- Trả lời từng câu hỏi phân tích của đề, đánh số theo đề. Mỗi nhận định: hiện tượng, cơ chế
(dẫn tới hàm hoặc tham số), bằng chứng (dẫn tới bảng hoặc hình ở mục 5), giới hạn của kết luận. -->

{phân tích}

## 7. Ý nghĩa đối với bảo mật

<!-- 3 đến 6 câu: thay đổi em vừa đo có lợi hay hại cho ai, kẻ tấn công hay người dùng hợp lệ;
nếu triển khai thật thì chọn cấu hình nào, vì sao. -->

{ý nghĩa}

## 8. Sự cố gặp phải và cách xử lý

| Sự cố (thông báo lỗi) | Nguyên nhân | Cách xử lý |
|---|---|---|
| {hoặc ghi "Không có"} | | |

## 9. Dữ liệu sinh trắc, nguồn tham khảo và công cụ AI

- [ ] Kho không chứa ảnh vân tay, khuôn mặt, mống mắt, giọng nói của người thật, tập dữ liệu, tệp `.db`, `.pkl`, `.npy`, trọng số mô hình.
- [ ] Mã dùng lại của người khác đã ghi nguồn ngay trong chú thích mã.

Nguồn tham khảo: {tài liệu, trang web, kho mã, ngày truy cập}

Công cụ AI: {đã khai trong AI-SUDUNG.md, hoặc "Không dùng"}

## 10. Cam kết

Tôi cam kết các kết quả trong báo cáo này do chính tôi chạy trên máy của mình, các phần sử dụng lại của người khác đã được ghi nguồn đầy đủ.

{Họ và tên, ngày}
