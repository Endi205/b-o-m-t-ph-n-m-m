# LAB_9: Bảo vệ mẫu sinh trắc: BioHashing, cam kết mờ, so khớp trên dữ liệu mã hoá

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th09a_biohashing.py`
- `th09b_fuzzy_commitment.py`
- `th09c_encrypted_matching.py`
- `ket-qua/TH09a_bang-biohashing.csv`
- `ket-qua/TH09b_bang-cam-ket-mo.csv`
- `ket-qua/TH09c_bang-so-khop-ma-hoa.csv`

Tệp nên có:

- `ket-qua/TH09a_phan-bo-biohash.png`
- `ket-qua/TH09b_ber-va-nang-luc-sua-loi.png`

Phép tự kiểm sẽ xem:

- bảng BioHashing đủ 3 giá trị m
- EER khi mất token không nhỏ hơn EER khi token bí mật
- bảng cam kết mờ có ít nhất hai bộ mã
- EER trên bản mã bằng EER trên bản rõ, sai khác không quá 0,1 điểm phần trăm

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.
