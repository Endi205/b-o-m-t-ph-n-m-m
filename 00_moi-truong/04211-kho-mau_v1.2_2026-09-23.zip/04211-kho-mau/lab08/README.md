# LAB_8: Phát hiện tấn công trình diện và chèn dữ liệu có kiểm soát

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao.md`
- `th08_pad_eval.py`
- `th08_injection_lab.py`
- `ket-qua/TH08_bao-cao-pad.json`
- `ket-qua/TH08_nhat-ky-chen-du-lieu.json`

Phép tự kiểm sẽ xem:

- báo cáo PAD có APCER theo loài, APCER lớn nhất, BPCER, FTA
- nhật ký chèn dữ liệu có ít nhất 8 lần thử

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit.

Ghi chú: Không đưa ảnh hay video của người thật lên kho.
