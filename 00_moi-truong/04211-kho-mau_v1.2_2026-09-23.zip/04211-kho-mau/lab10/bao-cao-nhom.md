# Báo cáo nhóm LAB_10: Bài nhóm: hệ thống xác thực khuôn mặt có PAD và bảo vệ mẫu

<!-- Bài nhóm: chép nội dung mau-bao-cao-nhom.md của bài vào tệp này, và mau-mo-hinh-de-doa.md vào
tệp mo-hinh-de-doa.md cạnh đây. Kho của trưởng nhóm giữ bài; mọi thành viên dán cùng một đường dẫn commit. -->
