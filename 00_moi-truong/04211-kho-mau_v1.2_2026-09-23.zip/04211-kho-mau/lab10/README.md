# LAB_10: Bài nhóm: hệ thống xác thực khuôn mặt có PAD và bảo vệ mẫu

Tệp bắt buộc (dấu `*` là phần tên do chương trình tự đặt):

- `bao-cao-nhom.md`
- `mo-hinh-de-doa.md`
- `th10_he_thong.py`
- `trinh-bay.pdf`

Tệp nên có:

- `ket-qua/TH10_bao-cao-mo-phong.json`

Phép tự kiểm sẽ xem:

- báo cáo đánh giá do chương trình sinh ra

Cách đặt tệp: mã nguồn `.py` ở ngay thư mục này; bảng số liệu và đồ thị do chương trình ghi ra giữ nguyên tên trong `ket-qua/`; ảnh chụp màn hình trong `hinh/`.

Nộp trên LMS: Đường dẫn commit trong kho của trưởng nhóm; mọi thành viên dán cùng một đường dẫn.

Ghi chú: Dùng mau-bao-cao-nhom.md và mau-mo-hinh-de-doa.md của bài; không đưa TH10_kho-mau.json và TH10_nhat-ky.jsonl lên kho.
