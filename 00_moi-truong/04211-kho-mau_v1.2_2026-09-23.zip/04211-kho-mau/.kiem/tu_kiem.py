# -*- coding: utf-8 -*-
"""Tu kiem kho bai lam hoc phan 04211. Chay o goc kho: python .kiem/tu_kiem.py

Kiem tep cam (du lieu sinh trac), anh dat sai cho, tep qua lon; voi moi bai da bat dau viet
bao-cao.md: tep bat buoc, cau truc bao cao, va cac quy tac so lieu cong khai cua bai.
Tep nay sinh tu cong cu cua giang vien; dung sua.
"""
import io, json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kiem_chung as kc


def tep_trong_kho():
    try:
        r = subprocess.run(["git", "-c", "core.quotepath=off", "ls-files"], stdout=subprocess.PIPE, check=True)
        ds = [l for l in r.stdout.decode("utf-8", "replace").split("\n") if l]
    except Exception:
        ds = []
        for g, dirs, ts in os.walk("."):
            dirs[:] = [d for d in dirs if d != ".git"]
            ds += [os.path.relpath(os.path.join(g, t), ".").replace(os.sep, "/") for t in ts]
    return {p: os.path.getsize(p) for p in ds if os.path.isfile(p)}


def doc(p):
    with io.open(p, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def main():
    qu = json.loads(doc(os.path.join(".kiem", "quy-uoc.json")))
    kho = tep_trong_kho()
    tep = set(kho)
    anh = [m for q in qu.values() for m in q["do_thi"]]
    loi = list(zip(*kc.kiem_tep(tep, kho, anh)))
    for so_lab, q in sorted(qu.items(), key=lambda x: int(x[0])):
        tm = "lab%02d" % int(so_lab)
        bc = [p for p in (tm + "/bao-cao.md", tm + "/bao-cao-nhom.md") if p in tep]
        if not bc or doc(bc[0]).strip() == q["mau_bao_cao"].strip():
            continue  # bai chua bat dau
        for p in q["bat_buoc"]:
            if not kc.tim(tep, p):
                loi.append(("%s: THIEU TEP" % tm, p))
        if q["mau"] == "chung":
            co, ghi = kc.kiem_bao_cao(doc(bc[0]), tep, tm, q["mau_bao_cao"])
            loi += [("%s: %s" % (tm, c), g) for c, g in zip(co, ghi)]
        for r in q["quy_tac"]:
            dat, c, g = kc.kiem_quy_tac(r, doc, tm, tep)
            if not dat:
                loi.append(("%s: %s" % (tm, c), g))
    if loi:
        print("CAN SUA TRUOC KHI NOP:")
        for c, g in loi:
            print("  - %s: %s" % (c, g))
        return 1
    print("DAT: khong thay loi nao ma phep tu kiem bat duoc.")
    print("Phep tu kiem khong cham noi dung chuyen mon; phan do giang vien doc.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
