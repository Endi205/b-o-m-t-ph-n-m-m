# -*- coding: utf-8 -*-
"""Phep kiem dung chung cho kho bai lam hoc phan 04211 Bao mat sinh trac.

Tep nay nam o hai noi va phai GIONG HET nhau: canh gv-kiem-kho-nop-bai.py cua giang vien,
va trong .kiem/ cua kho mau ma sinh vien tao kho tu do. Vi vay sinh vien tu kiem va giang
vien kiem bang cung mot logic. Kich ban cua giang vien so ma bam cua ban trong kho sinh
vien voi ban nay; khac nhau la co co TEP KIEM BI SUA.

Chi dung thu vien chuan Python 3.8 tro len.
"""
import csv
import fnmatch
import io
import json
import os
import re

# --------------------------------------------------------------------------
# Tep cam va cho dat anh
# --------------------------------------------------------------------------
# Du lieu sinh trac tho, du lieu dan xuat (mau, embedding, kho mau, nhat ky), trong so,
# co so du lieu, moi truong ao, du lieu tai ve.
TEP_CAM = re.compile(
    r"(^|/)(venv|\.venv|env|__pycache__|du-lieu|du-lieu-rieng|du-lieu-pad|data|cache-embedding"
    r"|db-tham-chieu|mo-hinh|pretrained_models)/"
    r"|\.(db|sqlite3?|pkl|pickle|ldsa|npy|npz|h5|hdf5|onnx|pt|pth|ckpt|tflite|safetensors"
    r"|tif|tiff|bmp|wsq|jp2|wav|flac|mp3|m4a|ogg|mp4|avi|mov|mkv|jsonl)$"
    r"|(^|/)[^/]*(kho-mau|_tang-cuong|_xuong)[^/]*\.(json|png|jpe?g)$", re.I)
DUOI_ANH = (".png", ".jpg", ".jpeg")
CO_TOI_DA = 5 * 1024 * 1024


def khop(mau, duong_dan):
    return fnmatch.fnmatchcase(duong_dan, mau)


def tim(tep, mau):
    """Cac tep trong tap tep khop mau; mau ket thuc bang / la thu muc."""
    if mau.endswith("/"):
        return sorted(t for t in tep if t.startswith(mau) and not t.endswith("README.md"))
    return sorted(t for t in tep if khop(mau, t))


def kiem_tep(tep, co_tep=None, anh_duoc_phep=()):
    """Tep cam, anh dat sai cho, tep qua lon. anh_duoc_phep: cac mau duong dan anh duoc phep."""
    co, ghi = [], []
    cam = sorted(p for p in tep if TEP_CAM.search(p))
    if cam:
        co.append("CO TEP CAM")
        ghi.append("tep khong duoc dua len kho: " + ", ".join(cam[:6]))
    lac = sorted(p for p in tep if p.lower().endswith(DUOI_ANH) and not TEP_CAM.search(p)
                 and not re.match(r"^lab[0-9]{2}/hinh/[^/]+$", p)
                 and not any(khop(m, p) for m in anh_duoc_phep))
    if lac:
        co.append("ANH SAI CHO")
        ghi.append("anh chi duoc nam trong labNN/hinh/ hoac dung ten do thi cua bai: " + ", ".join(lac[:6]))
    if co_tep:
        lon = sorted(p for p, n in co_tep.items() if n > CO_TOI_DA)
        if lon:
            co.append("TEP QUA LON")
            ghi.append("tep tren 5 MB: " + ", ".join(lon[:6]))
    return co, ghi


# --------------------------------------------------------------------------
# Bao cao
# --------------------------------------------------------------------------
MUC_BAO_CAO = [
    "1. Tóm tắt kết quả",
    "2. Mức độ hoàn thành",
    "3. Môi trường thực hiện và khả năng tái lập",
    "4. Các bước thực hiện và minh chứng",
    "5. Kết quả định lượng",
    "6. Phân tích và thảo luận",
    "7. Ý nghĩa đối với bảo mật",
    "8. Sự cố gặp phải và cách xử lý",
    "9. Dữ liệu sinh trắc, nguồn tham khảo và công cụ AI",
    "10. Cam kết",
]
SO_TU_TOI_THIEU = 250  # so tu viet them so voi mau rong


def _sach(van_ban):
    van_ban = re.sub(r"(?s)<!--.*?-->", " ", van_ban)
    van_ban = re.sub(r"(?s)```.*?```", " ", van_ban)
    return re.sub(r"`[^`\n]*`", " ", van_ban)


def kiem_bao_cao(van_ban, tep, thu_muc, mau="", muc=None):
    co, ghi = [], []
    tieu_de = [re.sub(r"\s+", " ", m.group(1)).strip().lower()
               for m in re.finditer(r"(?m)^##\s+(.+?)\s*$", van_ban)]
    thieu = [m for m in (muc or MUC_BAO_CAO) if m.lower() not in tieu_de]
    if thieu:
        co.append("BAO CAO THIEU MUC")
        ghi.append("thieu muc: " + "; ".join(thieu))
    sach = _sach(van_ban)
    cho_trong = sorted(set(re.findall(r"\{[^{}\n]{1,60}\}", sach)))
    if cho_trong:
        co.append("CON CHO TRONG CUA MAU")
        ghi.append("con: " + ", ".join(cho_trong[:6]))
    so_tu = len(re.findall(r"\w+", sach, re.U)) - len(re.findall(r"\w+", _sach(mau), re.U))
    if so_tu < SO_TU_TOI_THIEU:
        co.append("BAO CAO QUA NGAN")
        ghi.append("viet them %d tu so voi mau, can it nhat %d" % (max(so_tu, 0), SO_TU_TOI_THIEU))
    for dich in re.findall(r"!\[[^\]]*\]\(([^)\s]+)\)", sach):
        if re.match(r"^[a-z]+://", dich):
            ghi.append("anh lay tu ngoai kho, nguoi cham co the khong mo duoc: " + dich[:60])
            continue
        duong = os.path.normpath(os.path.join(thu_muc, dich)).replace(os.sep, "/")
        if duong not in tep:
            co.append("ANH KHONG CO TRONG KHO")
            ghi.append("bao cao tro toi %s nhung kho khong co tep nay" % duong)
    return co, ghi


# --------------------------------------------------------------------------
# Quy tac tren bang so lieu
# --------------------------------------------------------------------------

def so(x):
    x = str(x if x is not None else "").strip().replace(",", ".").rstrip("%")
    return float(x)


def doc_csv(van_ban):
    return list(csv.DictReader(io.StringIO(van_ban.lstrip("﻿"))))


def _loc(hang, loc):
    for k, v in (loc or {}).items():
        gt = str(hang.get(k, "")).strip()
        try:
            if abs(so(gt) - so(v)) > 1e-9:
                return False
        except ValueError:
            if gt != str(v):
                return False
    return True


def _mo_ta(q):
    return q.get("mo_ta") or q["loai"]


def kiem_quy_tac(q, doc, thu_muc, tep, mssv=""):
    """Chay mot quy tac. doc(duong_dan) tra ve noi dung tep. Tra ve (dat, co, ghi).

    dat la True/False; co la ten co khi khong dat. Moi quy tac khong dat sinh dung mot co
    SO LIEU CHUA DAT kem mo ta, rieng loi dinh dang sinh co SAI DINH DANG SO LIEU.
    """
    ds = tim(tep, thu_muc + "/" + q["tep"]) if "tep" in q else []
    if "tep" in q and not ds:
        return False, "THIEU TEP SO LIEU", "%s: khong thay tep %s" % (_mo_ta(q), q["tep"])
    p = ds[-1] if ds else None
    try:
        L = q["loai"]
        if L == "ten_mssv":
            ten = os.path.basename(p)
            if "ma-sinh-vien" in ten or (mssv and mssv.upper() not in ten.upper()):
                return False, "TEN TEP KHONG MANG MSSV", "%s: %s" % (_mo_ta(q), ten)
            return True, "", ""
        if L == "json":
            d = json.loads(doc(p))
            thieu = [k for k in q.get("khoa", []) if k not in d]
            if thieu:
                return False, "SO LIEU CHUA DAT", "%s: thieu khoa %s" % (_mo_ta(q), ", ".join(thieu))
            for k, n in (q.get("do_dai") or {}).items():
                if len(d.get(k) or []) < n:
                    return False, "SO LIEU CHUA DAT", "%s: %s co %d phan tu, can it nhat %d" % (
                        _mo_ta(q), k, len(d.get(k) or []), n)
            return True, "", ""
        hang = doc_csv(doc(p))
        if L == "cot":
            thieu = [c for c in q["cot"] if not hang or c not in hang[0]]
            if thieu:
                return False, "SAI DINH DANG SO LIEU", "%s: %s thieu cot %s" % (_mo_ta(q), os.path.basename(p), ", ".join(thieu))
            if len(hang) < q.get("so_dong", 1):
                return False, "SO LIEU CHUA DAT", "%s: %d dong, can it nhat %d" % (_mo_ta(q), len(hang), q.get("so_dong", 1))
            return True, "", ""
        if L == "phan_biet":
            n = len(set(h[q["cot"]].strip() for h in hang))
            return (n >= q["it_nhat"], "SO LIEU CHUA DAT",
                    "%s: %d gia tri khac nhau cua %s, can it nhat %d" % (_mo_ta(q), n, q["cot"], q["it_nhat"]))
        if L == "co_dong":
            ok = any(_loc(h, q["dieu_kien"]) for h in hang)
            return ok, "SO LIEU CHUA DAT", "%s: khong co dong nao dung %s" % (_mo_ta(q), q["dieu_kien"])
        if L == "gia_tri":
            chon = [h for h in hang if _loc(h, q.get("loc"))]
            if not chon:
                return False, "SO LIEU CHUA DAT", "%s: khong co dong nao khop %s" % (_mo_ta(q), q.get("loc"))
            for h in chon:
                v = so(h[q["cot"]])
                if ("abs_max" in q and abs(v) > q["abs_max"]) or ("min" in q and v < q["min"]) \
                        or ("max" in q and v > q["max"]):
                    return False, "SO LIEU CHUA DAT", "%s: %s = %s" % (_mo_ta(q), q["cot"], h[q["cot"]])
            return True, "", ""
        if L == "hieu":
            for h in hang:
                d = so(h[q["a"]]) - so(h[q["b"]])
                if ("abs_max" in q and abs(d) > q["abs_max"]) or ("min" in q and d < q["min"]):
                    return False, "SO LIEU CHUA DAT", "%s: %s - %s = %.4g" % (_mo_ta(q), q["a"], q["b"], d)
            return True, "", ""
        if L == "tang_dan":
            day = sorted(((so(h[q["theo"]]), so(h[q["cot"]])) for h in hang))
            ok = all(b[1] >= a[1] for a, b in zip(day, day[1:]))
            return ok, "SO LIEU CHUA DAT", "%s: %s khong tang theo %s" % (_mo_ta(q), q["cot"], q["theo"])
        if L == "frr_far":
            return kiem_frr_far(doc(tim(tep, thu_muc + "/" + q["luot"])[-1]) if tim(tep, thu_muc + "/" + q["luot"]) else "",
                                doc(p), _mo_ta(q))
        return False, "SAI DINH DANG SO LIEU", "quy tac la: %s" % L
    except (KeyError, ValueError, TypeError, IndexError) as e:
        return False, "SAI DINH DANG SO LIEU", "%s: %s %s" % (_mo_ta(q), type(e).__name__, e)


def kiem_frr_far(van_ban_luot, van_ban_bang, mo_ta="FRR, FAR tinh lai tu tung luot"):
    """Tinh lai FRR, FAR tu tep tung luot (cau_hinh, loai_luot, diem, nguong, chap_nhan) va so voi bang."""
    if not van_ban_luot:
        return False, "THIEU TEP SO LIEU", mo_ta + ": khong thay tep tung luot"
    tinh = {}
    for i, h in enumerate(doc_csv(van_ban_luot), 2):
        cn = int(so(h["chap_nhan"]))
        if cn != int(so(h["diem"]) >= so(h["nguong"])):
            return False, "QUYET DINH TRAI NGUONG", "dong %d: diem %s, nguong %s, chap_nhan %s" % (
                i, h["diem"], h["nguong"], h["chap_nhan"])
        t = tinh.setdefault(h["cau_hinh"].strip(), [0, 0, 0, 0])
        loai = h["loai_luot"].strip().lower()
        if loai == "cung-ngon":
            t[0] += 1
            t[1] += 1 - cn
        elif loai == "khac-ngon":
            t[2] += 1
            t[3] += cn
        else:
            return False, "SAI DINH DANG SO LIEU", "dong %d: loai_luot '%s'" % (i, loai)
    lech = []
    for h in doc_csv(van_ban_bang):
        t = tinh.get(h["cau_hinh"].strip())
        if not t:
            lech.append("%s khong co luot nao" % h["cau_hinh"])
            continue
        frr = 100.0 * t[1] / t[0] if t[0] else float("nan")
        far = 100.0 * t[3] / t[2] if t[2] else float("nan")
        if int(so(h["so_luot_cung_ngon"])) != t[0] or int(so(h["so_luot_khac_ngon"])) != t[2]:
            lech.append("%s: so luot ghi %s/%s, dem %d/%d" % (h["cau_hinh"], h["so_luot_cung_ngon"], h["so_luot_khac_ngon"], t[0], t[2]))
        if abs(so(h["frr"]) - frr) > 0.06 or abs(so(h["far"]) - far) > 0.06:
            lech.append("%s: bang ghi FRR %s FAR %s, tinh lai %.2f %.2f" % (h["cau_hinh"], h["frr"], h["far"], frr, far))
    if lech:
        return False, "SO LIEU KHONG KHOP", "; ".join(lech[:4])
    return True, "", ""
