# -*- coding: utf-8 -*-
"""Chay kiem thu cong khai cua cac bai da co du tep. Chay o goc kho: python .kiem/chay_kiem_thu.py

Chi chay tren may cua GitHub (the Actions) hoac may cua chinh sinh vien. Tep nay sinh tu
cong cu cua giang vien; dung sua.
"""
import io, json, os, subprocess, sys

def main():
    with io.open(os.path.join(".kiem", "quy-uoc.json"), encoding="utf-8") as fh:
        qu = json.load(fh)
    da_cai, hong, chay = set(), [], 0
    for so_lab, q in sorted(qu.items(), key=lambda x: int(x[0])):
        kt = q.get("kiem_thu")
        tm = "lab%02d" % int(so_lab)
        if not kt or not all(os.path.isfile(os.path.join(tm, p)) for p in kt["can"]):
            continue
        can_cai = [g for g in kt["cai"] if g not in da_cai]
        if can_cai:
            subprocess.run([sys.executable, "-m", "pip", "install", "--quiet"] + can_cai, check=False)
            da_cai.update(can_cai)
        for lenh in kt["lenh"]:
            chay += 1
            print("== %s: %s" % (tm, lenh), flush=True)
            r = subprocess.run(lenh.replace("python ", sys.executable + " ", 1), shell=True, cwd=tm, timeout=600)
            if r.returncode != 0:
                hong.append("%s: %s" % (tm, lenh))
    if not chay:
        print("Chua co bai nao du tep de chay kiem thu cong khai.")
        return 0
    if hong:
        print("KIEM THU CHUA DAT: " + "; ".join(hong))
        return 1
    print("KIEM THU DAT: %d lenh." % chay)
    return 0

if __name__ == "__main__":
    sys.exit(main())
